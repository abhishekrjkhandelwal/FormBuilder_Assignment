export class Form {
    name?: string;
    email?: string;
    gender?: string;
    adhaarNumber?: string;
    country?: string;
    address?: string;
    createdAt?: Date;
    dob?: any;
    mobileno?: String;
    imagePath?: string;
}
